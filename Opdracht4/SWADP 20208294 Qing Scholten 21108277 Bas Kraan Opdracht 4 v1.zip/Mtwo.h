#ifndef __Mtwo_H
#define __Mtwo_H

#include "Motor.h"

class Mtwo: public Motor {
public:
	virtual ~Mtwo() {}
};

#endif