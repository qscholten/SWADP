#ifndef __Mone_H
#define __Mone_H

#include "Motor.h"

class Mone: public Motor {
public:
	virtual ~Mone() {}
};

#endif